
__progname__ = "si-grabber"
__description__ = "Spectral instruments(c) image grabber"
__author__ = "P. Henrique Silva <henrique@astro.ufsc.br>"
__license__ = "GPL v2"
__version__ = "0.2"

__copyleft__ = "%s\n%s (%s)\n%s" % (
    __progname__, __description__, __version__, __author__)
